class VaultWarderError(Exception):
    """ Something wrong """


class VaultItemNotFound(Exception):
    """ If we can't find item by id """
